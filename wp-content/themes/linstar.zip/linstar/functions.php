<?php

/*
*	Loading DEVN's framework and HUBs library
*	(c) king-theme.com
*
*/

#Load core of theme
include 'core/king.define.php';
#
#
#	END of REGISTRATION
#
#
