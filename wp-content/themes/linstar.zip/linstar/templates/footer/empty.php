<?php

	// KING
	
?>