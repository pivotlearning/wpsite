/***
*
* (c) king-theme.com
*
*/

If you want to change any js file, just copy that file from main-template and paste here before edit.

main-files located: wp-content/themes/linstar/assets/js/