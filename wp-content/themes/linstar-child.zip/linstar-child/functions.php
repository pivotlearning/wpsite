<?php

/*
*	Child-Theme functions
*	(c) king-theme.com
*
*/

