/***
*
* (c) king-theme.com
*
*/

If you want to change any template file, just copy that file from main-template and paste here before edit.

main-files located: wp-content/themes/linstar/templates/